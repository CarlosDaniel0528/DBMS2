@extends('template.temp')

@section('content')
<h1 class="h1">Event Details</h1>
<form action="{{route('events.store')}}" method="POST">
    @csrf
    <div>
        <input type="text" name="eventName" placeholder="Event Name" required>
        <input type="date" name="date" placeholder="Date" required>
        <input type="text" name="location" placeholder="Location" required>
        <button type="submit">Save</button>
        <form action="{{route('events.index')}}">
            <button class="icon"><i class="fa fa-arrow-left"> Back</i></button>
        </form>
    </div>
</form>
@endsection

