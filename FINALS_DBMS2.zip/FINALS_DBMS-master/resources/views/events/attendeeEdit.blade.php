@extends('template.temp')



@section('content')
<div class="d"><br><br><br>
    <h1 class="h1">Edit Event</h1><br>
    <form action="{{route('attend.update',[$attendee->id])}}" method="POST">
        @csrf
        @method('PUT')
        <div class=".d">
            <input type="text" name="name" value="{{$attendee->name}}" placeholder="name" required autocomplete="off" class="inp">
            <input type="hidden" name="id" value="{{$attendee->event_id}}">
            <button type="submit" class="sv"> Save <i class="fa fa-check-square-o"></i></button>
            <form action="{{route('events.index')}}">
                <button class="icon" id="bt"><i class="fa fa-arrow-left"> Back</i></button>
            </form>
        </div> 
    </form>
</div>
@endsection