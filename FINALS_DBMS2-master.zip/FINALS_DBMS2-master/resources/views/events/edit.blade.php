@extends('template.temp')

@section('title')
{{$event->eventName}}
@endsection

@section('content')
<div class="d"><br><br><br>
    <h1 class="h1">Edit Event</h1><br>
    <form action="{{route('events.update',[$event->id])}}" method="POST">
        @csrf
        @method('PUT')
        <div class=".d">
            <input type="text" name="eventName" value="{{$event->eventName}}" placeholder="eventName" required autocomplete="off" class="inp">
            <input type="date" name="date" value="{{$event->date}}" placeholder="date" required autocomplete="off" class="inp">
            <input type="text" name="location" value="{{$event->location}}" placeholder="location" required autocomplete="off" class="inp">
            <button type="submit" class="sv"> Save <i class="fa fa-check-square-o"></i></button>
        </div> 
    </form>
    <form action="{{route('events.index')}}">
        <button class="icon" id="bt"><i class="fa fa-arrow-left"> Back</i></button>
    </form>
</div>
@endsection