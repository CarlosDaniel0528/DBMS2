@extends('template.temp')

@section('title')
{{$attendee->name}}
@endsection

@section('content')
<div class="d"><br><br><br>
    <h1 class="h1">Edit Attendee</h1><br>
    <form action="{{route('attend.update',[$attendee->id])}}" method="POST">
        @csrf
        @method('PUT')
        <div class=".d">
            <input type="text" name="name" value="{{$attendee->name}}" placeholder="name" required autocomplete="off" class="inp">
            <input type="string" id="event_id" name="event_id" value="{{$attendee->event_id}}" hidden>
            <button type="submit" class="sv"> Save <i class="fa fa-check-square-o"></i></button>   
        </div> 
    </form>
    <form action="{{route('events.show', [$attendee->event_id])}}">
        <button class="icon" id="bt"><i class="fa fa-arrow-left"> Back</i></button>
    </form>
</div>
@endsection