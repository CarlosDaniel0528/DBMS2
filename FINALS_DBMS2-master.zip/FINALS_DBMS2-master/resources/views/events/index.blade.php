@extends('template.temp')

@section('title')
    Event Registration
@endsection

@section('content')
<div class="d"><br><br>
    <h1 class="h1">EVENT REGISTRATION</h1>
    <p>DATABASE MANAGEMENT SYSTEM II</p><br>
    <form action="{{route('events.store')}}" method="POST">
        @csrf
        <div>
            <input type="text" name="eventName" placeholder="Event Name" required autocomplete="off" class="inp">
            <input type="date" name="date" placeholder="Event Date" value="Event Date" required autocomplete="off" class="inp">
            <input type="text" name="location" placeholder="Event Location" required autocomplete="off" class="inp">
            <button type="submit" id="s" class="inp">Save Event</button>
        </div>
    </form><br>
    <div class="tb1">
        <table>
            <thead>
                <tr>
                    <th class="num"></th>
                    <th class="c">Event Name</th>
                    <th class="c">Date</th>
                    <th class="c">Location</th>
                    <th class="ac">Action</th>
                </tr>
            </thead>
            <tbody>
                @php $rowNumber = 1; @endphp
                @forelse ($events as $q)
                    <tr>
                        <td class="num">{{$rowNumber++}}</td>
                        <td class="c">{{$q->eventName}}</td>
                        <td class="c">{{$q->date}}</td>
                        <td class="c">{{$q->location}}</td>
                        <td class="ac">
                            <div class="acc">
                                <form action="{{route('events.show',[$q->id])}}" >
                                    @csrf
                                    <button class="icon"><i class="fa fa-eye"></i></button>
                                </form>
                                <form action="{{route('events.edit',[$q->id])}}">
                                    @csrf
                                    <button class="icon"><i class="fa fa-pencil-square-o"></i></button>
                                </form>
                                <form action="{{route('events.destroy',[$q->id])}}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="icon"><i class="fa fa-trash"></i></button>
                                </form>
                           </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6">No Events Registered Yet</td>
                    </tr>
                @endforelse    
            </tbody>
        </table>
    </div>
</div>
@endsection
