@extends('template.temp')

@section('title')
{{$event->eventName}}
@endsection

@section('content')
<div class="s"><br>
    <div class="aside" >
        <h1 class="h1" style="border-bottom: 1px solid black;">{{$event->eventName}}</h1>
        <p>When: {{$event->date}}</p>
        <p>Where: {{$event->location}}</p>
        <form action="{{route('events.index')}}">
            <button class="icon"><i class="fa fa-arrow-left"> Back</i></button>
        </form>
        <form action="{{route('events.storeAttendee')}}" method="POST">
            @csrf
            <div>
                <input type="text" name="name" placeholder="Attendee Name" required autocomplete="off" class="inp">
                <input type="integer" id="event_id" name="event_id" value="{{$event->id}}" hidden>
                <button type="submit" class="inp">Add</button>
            </div>
        </form>
    </div><br>
    <div class="tb">
        <table class="q">
            <thead>
                <tr>
                    <th class="num"></th>
                    <th class="c">Attendee Name</th>
                    <th class="ac">Action</th>
                </tr>
            </thead>
            <tbody>
                @php $rowNumber = 1; @endphp
                @forelse ($attend as $i)
                    <tr>
                        <td class="num">{{$rowNumber++}}</td>
                        <td class="c">{{$i->name}}</td>
                        <td class="ac">
                            <div class="acc">
                                <form action="{{route('attend.edit',[$i->id])}}">
                                    @csrf
                                    <button class="icon"><i class="fa fa-pencil-square-o"></i></button>
                                </form>
                                <form action="{{route('attend.destroy',[$i->id])}}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="icon"><i class="fa fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <td colspan="3">NO DATA</td>
                @endforelse
                
            </tbody>
        </table>
    </div>
</div>
@endsection
